<!DOCTYPE TS><TS>
<context>
    <name>design/abpdfcatalogue/view</name>
    <message>
        <source>Create catalogue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have the permission to generate a personal PDF catalogue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No documents selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the mouse to drag catalogue documents and drop them in the target zone</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pdfcatalogue</name>
    <message>
        <source>Page %1 of %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
