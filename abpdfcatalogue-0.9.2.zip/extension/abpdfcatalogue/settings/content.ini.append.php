<?php /*

[ActionSettings]
ExtensionDirectories[]=abpdfcatalogue

*/ ?>
