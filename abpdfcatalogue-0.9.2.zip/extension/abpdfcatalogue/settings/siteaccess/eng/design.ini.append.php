<?php /*

#[StylesheetSettings]
#CSSFileList[]=yui/fonts/fonts-min.css
#CSSFileList[]=yui/tabview/assets/skins/sam/tabview.css

#[JavaScriptSettings]
#JavaScriptList[]=yui/yahoo-dom-event/yahoo-dom-event.js
#JavaScriptList[]=yui/animation/animation-min.js
#JavaScriptList[]=yui/connection/connection-min.js
#JavaScriptList[]=yui/dragdrop/dragdrop-min.js
#JavaScriptList[]=yui/get/get-min.js
#JavaScriptList[]=yui/json/json-min.js
#JavaScriptList[]=yui/element/element-min.js
#JavaScriptList[]=yui/tabview/tabview-min.js
#JavaScriptList[]=ezdatepicker.js

*/ ?>
