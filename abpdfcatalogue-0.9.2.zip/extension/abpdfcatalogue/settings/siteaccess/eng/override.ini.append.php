<?php /* #?ini charset="utf8"?

[full_ab_pdf_catalogue]
Source=node/view/full.tpl
MatchFile=pdfcatalogue.tpl
Subdir=templates
Match[class_identifier]=ab_pdf_catalogue

[left_menu_ab_pdf_catalogue]
Source=menu/flat_left.tpl
MatchFile=pdf_catalogue_left_menu.tpl
Subdir=templates
Match[class_identifier]=ab_pdf_catalogue

*/ ?>
